import re

matcher=re.finditer("a{2,3}","abaabaaab") 
for match in matcher:
    print(match.start(),"...",match.group())