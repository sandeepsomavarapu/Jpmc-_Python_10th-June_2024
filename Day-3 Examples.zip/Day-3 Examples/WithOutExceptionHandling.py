try:
    f=open("simple1.txt","r")
    f.read()
    num=int(input("Enter Denominator for division : "))#0
    result = 12 /num #PVM
    print("Result is", result)#error code/risky code 
except ZeroDivisionError as ex:
    print("Dont enter zero as denominator",ex.__class__)  
except ValueError:
    print("Enter only number for division")  
except Exception as ex:
    print ("Some Other Error .....",ex.__class__)         
print("Remaining lines of code")





#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












